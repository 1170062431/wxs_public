package com.jieli.otasdk_java.base;

import com.jieli.component.base.Jl_BaseFragment;

/**
 * @ClassName: BaseFragment
 * @Description: java类作用描述
 * @Author: ZhangHuanMing
 * @CreateDate: 2021/12/23 9:36
 */
public class BaseFragment extends Jl_BaseFragment {
}
