package com.jieli.otasdk_java.tool;

import android.bluetooth.BluetoothDevice;
import android.os.ParcelUuid;
import android.text.TextUtils;

import com.jieli.jl_bt_ota.constant.StateCode;
import com.jieli.jl_bt_ota.util.BluetoothUtil;
import com.jieli.jl_bt_ota.util.CommonUtil;
import com.jieli.otasdk_java.tool.ota.OTAManager;
import com.jieli.otasdk_java.tool.ota.ble.BleManager;
import com.jieli.otasdk_java.tool.ota.ble.interfaces.BleEventCallback;
import com.jieli.otasdk_java.tool.ota.ble.model.BleScanInfo;
import com.jieli.otasdk_java.util.AppUtil;
import com.jieli.otasdk_java.util.JL_Constant;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * @ClassName: DevScanPresenter
 * @Description: java类作用描述
 * @Author: ZhangHuanMing
 * @CreateDate: 2021/12/23 10:04
 */
public class DevScanPresenter implements IDeviceContract.IDevScanPresenter {
    private final BleManager bleManager = BleManager.getInstance();
    private int interval = 0;

    public static final int MAX_INTERVAL = 12;
    private final IDeviceContract.IDevScanView view;

    public DevScanPresenter(IDeviceContract.IDevScanView view) {
        this.view = view;
    }

    @Override
    public void start() {
        bleManager.registerBleEventCallback(mBleEventCallback);

    }

    @Override
    public void destroy() {
        bleManager.unregisterBleEventCallback(mBleEventCallback);
    }

    @Override
    public boolean isScanning() {
        return bleManager.isBleScanning();
    }

    @Override
    public void startScan() {
        if (BluetoothUtil.isBluetoothEnable()) {
            bleManager.startLeScan(12000);
        } else {
            AppUtil.enableBluetooth();
        }
    }

    @Override
    public void stopScan() {
        bleManager.stopLeScan();
    }

    @Override
    public BluetoothDevice getConnectedDevice() {
        return bleManager.getConnectedBtDevice();
    }

    @Override
    public void connectBtDevice(BluetoothDevice device) {
        if (bleManager.getConnectedBtDevice() != null) {
            bleManager.disconnectBleDevice(bleManager.getConnectedBtDevice());
        } else {
            bleManager.connectBleDevice(device);
        }
    }

    @Override
    public void disconnectBtDevice(BluetoothDevice device) {
        bleManager.disconnectBleDevice(device);
    }

    private void stopEdrScan() {
        if (interval > 0) {
            interval = 0;
            view.onScanStatus(JL_Constant.SCAN_STATUS_IDLE, null);
            CommonUtil.getMainHandler().removeCallbacks(mScanSppDevice);
        }
    }

    public boolean deviceHasProfile(BluetoothDevice device, UUID uuid) {
        if (!BluetoothUtil.isBluetoothEnable()) {
            return false;
        } else if (device == null) {
            return false;
        } else if (TextUtils.isEmpty(uuid.toString())) {
            return false;
        } else {
            boolean ret = false;
            ParcelUuid[] uuids = device.getUuids();
            if (uuids == null) {
                return false;
            }
            for (ParcelUuid uid : uuids) {
                if (uuid.toString().toLowerCase(Locale.getDefault()).equals(uid.toString())) {
                    ret = true;
                    break;
                }
            }
            return ret;
        }
    }

    private final Runnable mScanSppDevice = new Runnable() {
        @Override
        public void run() {
            if (interval == 0) {
                view.onScanStatus(JL_Constant.SCAN_STATUS_SCANNING, null);
            }
            List<BluetoothDevice> connectedDeviceList = BluetoothUtil.getSystemConnectedBtDeviceList();
            if (connectedDeviceList != null && !connectedDeviceList.isEmpty()) {
                ArrayList<BluetoothDevice> edrList = new ArrayList<>();
                for (BluetoothDevice device : connectedDeviceList) {
                    int devType = device.getType();
                    boolean isHasA2dp = deviceHasProfile(device, JL_Constant.UUID_A2DP);
                    boolean isHasSpp = deviceHasProfile(device, JL_Constant.UUID_SPP);
                    if (devType != BluetoothDevice.DEVICE_TYPE_LE
                            && isHasA2dp && isHasSpp
                    ) {
                        boolean isContains = edrList.contains(device);
                        if (!isContains) {
                            edrList.add(device);
                            view.onScanStatus(JL_Constant.SCAN_STATUS_FOUND_DEV, device);
                        }
                    }
                }
            }
            if (interval >= MAX_INTERVAL) {
                interval = 0;
                view.onScanStatus(JL_Constant.SCAN_STATUS_IDLE, null);
            } else {
                interval++;
                CommonUtil.getMainHandler().postDelayed(this, 1000);
            }
        }
    };


    private void handleAdapterStatus(boolean bEnabled) {
        if (bEnabled) {
            startScan();
        } else {
            stopEdrScan();
            view.onScanStatus(JL_Constant.SCAN_STATUS_IDLE, null);
            view.onConnectStatus(
                    getConnectedDevice(),
                    StateCode.CONNECTION_DISCONNECT
            );
        }
    }

    private void handleDiscoveryStatus(boolean bStart) {
        view.onScanStatus(bStart ? JL_Constant.SCAN_STATUS_SCANNING : JL_Constant.SCAN_STATUS_IDLE, null);
        if (bStart && getConnectedDevice() != null) {
            view.onScanStatus(
                    JL_Constant.SCAN_STATUS_FOUND_DEV,
                    getConnectedDevice()
            );
        }
    }

    private void handleDiscoveryDevice(BluetoothDevice device) {
        if (device != null && BluetoothUtil.isBluetoothEnable()) {
            view.onScanStatus(JL_Constant.SCAN_STATUS_FOUND_DEV, device);
        }
    }

    private void handleConnection(BluetoothDevice device, int status) {
        view.onConnectStatus(device, status);
    }

    private final BleEventCallback mBleEventCallback = new BleEventCallback() {
        @Override
        public void onAdapterChange(boolean bEnabled) {
            handleAdapterStatus(bEnabled);
        }

        @Override
        public void onDiscoveryBleChange(boolean bStart) {
            handleDiscoveryStatus(bStart);
        }

        @Override
        public void onDiscoveryBle(BluetoothDevice device, BleScanInfo bleScanMessage) {
            handleDiscoveryDevice(device);
        }

        @Override
        public void onBleConnection(BluetoothDevice device, int status) {
            handleConnection(device, OTAManager.changeConnectStatus(status));
        }
    };
}
