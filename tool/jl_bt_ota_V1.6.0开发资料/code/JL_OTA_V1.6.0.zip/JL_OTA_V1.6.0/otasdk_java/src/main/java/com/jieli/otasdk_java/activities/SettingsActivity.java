package com.jieli.otasdk_java.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;

import androidx.databinding.DataBindingUtil;

import com.jieli.component.utils.SystemUtil;
import com.jieli.component.utils.ToastUtil;
import com.jieli.jl_bt_ota.util.PreferencesHelper;
import com.jieli.otasdk_java.BuildConfig;
import com.jieli.otasdk_java.R;
import com.jieli.otasdk_java.base.BaseActivity;
import com.jieli.otasdk_java.databinding.ActivitySettingsBinding;
import com.jieli.otasdk_java.util.JL_Constant;

import org.jetbrains.annotations.Nullable;

/**
 * @ClassName: SettingsActivity
 * @Description: java类作用描述
 * @Author: ZhangHuanMing
 * @CreateDate: 2021/12/22 14:29
 */
public class SettingsActivity extends BaseActivity {


    public static SettingsActivity newInstance() {
        return new SettingsActivity();
    }

    private boolean isChangeConfiguration = false;
    private boolean isUseDeviceAuth = false;
    private boolean isHidDevice = false;
    private boolean useCustomReconnectWay = false;
    private ActivitySettingsBinding binding;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_settings);
        isUseDeviceAuth = PreferencesHelper.getSharedPreferences(getApplicationContext())
                .getBoolean(JL_Constant.KEY_IS_USE_DEVICE_AUTH, JL_Constant.IS_NEED_DEVICE_AUTH);
        isHidDevice = PreferencesHelper.getSharedPreferences(getApplicationContext())
                .getBoolean(JL_Constant.KEY_IS_HID_DEVICE, JL_Constant.HID_DEVICE_WAY);
        useCustomReconnectWay = PreferencesHelper.getSharedPreferences(getApplicationContext())
                .getBoolean(
                        JL_Constant.KEY_USE_CUSTOM_RECONNECT_WAY,
                        JL_Constant.NEED_CUSTOM_RECONNECT_WAY
                );

        initView();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        isChangeConfiguration = false;
    }

    private void initView() {
        binding.tvSettingsVersionValue.setText(String.format(" : %s", SystemUtil.getVersioName(getApplicationContext())));
        if (!BuildConfig.DEBUG) {
            binding.tvSettingsTopRight.setVisibility(View.GONE);
            binding.clSettingsContainer.setVisibility(View.GONE);
            return;
        }
        binding.tvSettingsTopRight.setVisibility(View.VISIBLE);
        binding.clSettingsContainer.setVisibility(View.VISIBLE);
        binding.cbSettingsDeviceAuth.setChecked(isUseDeviceAuth);
        binding.cbSettingsHidDevice.setChecked(isHidDevice);
        binding.cbSettingsCustomReconnectWay.setChecked(useCustomReconnectWay);
        binding.tvSettingsTopLeft.setOnClickListener(v -> finish());
        binding.tvSettingsTopRight.setOnClickListener(v -> {
            PreferencesHelper.putBooleanValue(
                    getApplicationContext(),
                    JL_Constant.KEY_IS_USE_DEVICE_AUTH,
                    binding.cbSettingsDeviceAuth.isChecked()
            );
            PreferencesHelper.putBooleanValue(
                    getApplicationContext(),
                    JL_Constant.KEY_IS_HID_DEVICE,
                    binding.cbSettingsHidDevice.isChecked()
            );
            PreferencesHelper.putBooleanValue(
                    getApplicationContext(),
                    JL_Constant.KEY_USE_CUSTOM_RECONNECT_WAY,
                    binding.cbSettingsCustomReconnectWay.isChecked()
            );
            checkIsChangeConfiguration();
            if (isChangeConfiguration) {
                isChangeConfiguration = false;
                ToastUtil.showToastShort(R.string.settings_success_and_restart);
//                SystemUtil.restartApp(applicationContext)
                new Handler().postDelayed(() -> {
                    finish();
                    sendBroadcast(new Intent(JL_Constant.ACTION_EXIT_APP));
                }, 1000L);
            }
        });

        binding.btnSendFileSnapdrop.setOnClickListener(v -> {
            Intent intent = new Intent(this, SnapDropActivity.class);
            startActivity(intent);
        });
    }

    private void checkIsChangeConfiguration() {
        boolean isUseDeviceAuthNow = PreferencesHelper.getSharedPreferences(getApplicationContext())
                .getBoolean(JL_Constant.KEY_IS_USE_DEVICE_AUTH, JL_Constant.IS_NEED_DEVICE_AUTH);
        boolean isHidDeviceNow = PreferencesHelper.getSharedPreferences(getApplicationContext())
                .getBoolean(JL_Constant.KEY_IS_HID_DEVICE, JL_Constant.HID_DEVICE_WAY);
        boolean useCustomReconnectWayNow = PreferencesHelper.getSharedPreferences(getApplicationContext())
                .getBoolean(
                        JL_Constant.KEY_USE_CUSTOM_RECONNECT_WAY,
                        JL_Constant.NEED_CUSTOM_RECONNECT_WAY
                );
        isChangeConfiguration =
                (isUseDeviceAuthNow != isUseDeviceAuth || isHidDeviceNow != isHidDevice || useCustomReconnectWayNow != useCustomReconnectWay);
    }
}
