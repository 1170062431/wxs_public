package com.jieli.otasdk.activities

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.view.View
import com.jieli.component.utils.SystemUtil
import com.jieli.component.utils.ToastUtil
import com.jieli.jl_bt_ota.util.PreferencesHelper
import com.jieli.otasdk.BuildConfig
import com.jieli.otasdk.R
import com.jieli.otasdk.base.BaseActivity
import com.jieli.otasdk.util.JL_Constant
import kotlinx.android.synthetic.main.activity_settings.*

class SettingsActivity : BaseActivity() {

    companion object {

        fun newInstance(): SettingsActivity {
            return SettingsActivity()
        }
    }

    private var isChangeConfiguration = false
    private var isUseDeviceAuth = false
    private var isHidDevice = false
    private var useCustomReconnectWay = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        isUseDeviceAuth = PreferencesHelper.getSharedPreferences(applicationContext)
            .getBoolean(JL_Constant.KEY_IS_USE_DEVICE_AUTH, JL_Constant.IS_NEED_DEVICE_AUTH)
        isHidDevice = PreferencesHelper.getSharedPreferences(applicationContext)
            .getBoolean(JL_Constant.KEY_IS_HID_DEVICE, JL_Constant.HID_DEVICE_WAY)
        useCustomReconnectWay = PreferencesHelper.getSharedPreferences(applicationContext)
            .getBoolean(
                JL_Constant.KEY_USE_CUSTOM_RECONNECT_WAY,
                JL_Constant.NEED_CUSTOM_RECONNECT_WAY
            )

        initView()

    }

    override fun onDestroy() {
        super.onDestroy()
        isChangeConfiguration = false
    }

    private fun initView() {

        tv_settings_version_value.text =
            String.format(" : %s", SystemUtil.getVersioName(applicationContext))
        if (!BuildConfig.DEBUG) {
            tv_settings_top_right.visibility = View.GONE
            cl_settings_container.visibility = View.GONE
            return
        }
        tv_settings_top_right.visibility = View.VISIBLE
        cl_settings_container.visibility = View.VISIBLE
        cb_settings_device_auth.isChecked = isUseDeviceAuth
        cb_settings_hid_device.isChecked = isHidDevice
        cb_settings_custom_reconnect_way.isChecked = useCustomReconnectWay
        tv_settings_top_left.setOnClickListener {
            finish()
        }
        tv_settings_top_right.setOnClickListener {
            PreferencesHelper.putBooleanValue(
                applicationContext,
                JL_Constant.KEY_IS_USE_DEVICE_AUTH,
                cb_settings_device_auth.isChecked
            )
            PreferencesHelper.putBooleanValue(
                applicationContext,
                JL_Constant.KEY_IS_HID_DEVICE,
                cb_settings_hid_device.isChecked
            )
            PreferencesHelper.putBooleanValue(
                applicationContext,
                JL_Constant.KEY_USE_CUSTOM_RECONNECT_WAY,
                cb_settings_custom_reconnect_way.isChecked
            )
            checkIsChangeConfiguration()
            if (isChangeConfiguration) {
                isChangeConfiguration = false
                ToastUtil.showToastShort(R.string.settings_success_and_restart)
//                SystemUtil.restartApp(applicationContext)
                Handler().postDelayed({
                    finish()
                    sendBroadcast(Intent(JL_Constant.ACTION_EXIT_APP))
                }, 1000L)
            }
        }
        btn_send_file_snapdrop.setOnClickListener {
            val intent = Intent(this, SnapDropActivity::class.java);
            startActivity(intent)
        }
    }

    private fun checkIsChangeConfiguration() {
        val isUseDeviceAuthNow = PreferencesHelper.getSharedPreferences(applicationContext)
            .getBoolean(JL_Constant.KEY_IS_USE_DEVICE_AUTH, JL_Constant.IS_NEED_DEVICE_AUTH)
        val isHidDeviceNow = PreferencesHelper.getSharedPreferences(applicationContext)
            .getBoolean(JL_Constant.KEY_IS_HID_DEVICE, JL_Constant.HID_DEVICE_WAY)
        val useCustomReconnectWayNow = PreferencesHelper.getSharedPreferences(applicationContext)
            .getBoolean(
                JL_Constant.KEY_USE_CUSTOM_RECONNECT_WAY,
                JL_Constant.NEED_CUSTOM_RECONNECT_WAY
            )
        isChangeConfiguration =
            (isUseDeviceAuthNow != isUseDeviceAuth || isHidDeviceNow != isHidDevice || useCustomReconnectWayNow != useCustomReconnectWay)
    }
}
