#ifndef _OUTPUT_CHANNEL_H_
#define _OUTPUT_CHANNEL_H_

#include "typedef.h"

void output_channel(u8 ch, u8 ch_out);
void output_channel_demo();

#endif
