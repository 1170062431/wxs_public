
#ifndef _USER_PWM_H_
#define _USER_PWM_H_

#include "user_project.h"
#include "key_drv_tch.h"

#define USER_PWM0_EN		0
#define USER_PWM1_EN		0
#define USER_PWM2_EN		0
#define USER_PWM3_EN		1

#if USER_PWM0_EN	//timer0
#define USER_SET_PWM0 
#endif

#if USER_PWM1_EN	//timer1
#define USER_SET_PWM1 
#endif

#if USER_PWM2_EN	//timer2
#define USER_SET_PWM2 
#endif

#if USER_PWM3_EN	//timer3
#define USER_SET_PWM3_PND		0		//中断请求标志
#define USER_CLR_PWM3_PCLR	 	(JL_TIMER3->CON |=  (BIT(14)))		//写1清中断请求标志SET_PWM3_PND
#define USER_SET_PWM3_PWM_INV	0		//PWM输出反向
#define USER_SET_PWM3_PWM_EN	1		//PWM使能
#define USER_SET_PWM3_PSET3_0	0		//预分频n(1-16)，0~3-(1,4,16,64)*1;4~7-(1,4,16,64)*2;8~11-(1,4,16,64)*256;12~15-(1,4,16,64)*512;
#define USER_SET_PWM3_SSEL1_0	0		//时钟源，0=系统时钟24M，1=IO输入，2=OSC时钟，3=RC时钟
#define USER_SET_PWM3_MODE1_0	1		//工作模式，0=关闭，1=定时/计数模式，2=IO口上升捕获模式，3=IO口下降捕获模式

#define USER_SET_PWM3_PRD(x)		(JL_TIMER3->PRD = x)		//0x0030~0x07FF,48~2047,超过此范围需要分频
#define USER_SET_PWM3_PWM(x)		(JL_TIMER3->PWM = x)		//0~SET_PWM3_PRD

#define USER_SET_PWM3_ON	 		(JL_TIMER3->CON |=  (BIT(8)))
#define USER_SET_PWM3_OFF			(JL_TIMER3->CON &= ~(BIT(8)))
#endif

#define USER_TIME3_DIV_EN	0

#if 0	//调试版本
//#define SET_USER_PWM_FRE	10000	//频率
#define SET_USER_PWM_FRE	120	//31250	//频率24000，频率高了放歌会闪
//#define SET_USER_PWM_FRE	50000	//频率
#define SET_USER_PWM_DUTY_W	250	//100	//占空比

//满电高亮模式 >3.9V
#define SET_USER_PWM_DUTY_W_LV1_H_PHS1		190		//起始
#define SET_USER_PWM_DUTY_W_LV1_H_PHS2		249		//逐渐升高
#define SET_USER_PWM_DUTY_W_LV1_H_PHS3		110		//逐渐降低

#define SET_USER_PWM_DUTY_W_LV2_H_PHS1		100		//起始
#define SET_USER_PWM_DUTY_W_LV2_H_PHS2		80		//逐渐降低

#define SET_USER_PWM_DUTY_W_LV3_H_PHS1		38//20//55

#define SET_USER_PWM_DUTY_R_LV1_H_PHS1		30//20//40
#define SET_USER_PWM_DUTY_R_LV2_H_PHS1		20//35

//普通模式 3.7V-3.9V
#define SET_USER_PWM_DUTY_W_LV1_M_PHS1		80//35//70
#define SET_USER_PWM_DUTY_W_LV2_M_PHS1		60//30//65
#define SET_USER_PWM_DUTY_W_LV3_M_PHS1		25//20//55
#define SET_USER_PWM_DUTY_R_LV1_M_PHS1		30//20//40
#define SET_USER_PWM_DUTY_R_LV2_M_PHS1		20//35

//低电模式 <3.7V
#define SET_USER_PWM_DUTY_W_LV1_L_PHS1		78//35//70
#define SET_USER_PWM_DUTY_W_LV2_L_PHS1		42//30//65
#define SET_USER_PWM_DUTY_W_LV3_L_PHS1		17//20//55
#define SET_USER_PWM_DUTY_R_LV1_L_PHS1		30//20//40
#define SET_USER_PWM_DUTY_R_LV2_L_PHS1		20//35
#else	//生产版本
//#define SET_USER_PWM_FRE	10000	//频率
#define SET_USER_PWM_FRE	10000	//31250	//频率24000，频率高了放歌会闪
//#define SET_USER_PWM_FRE	50000	//频率
#define SET_USER_PWM_DUTY_W	2000	//100	//占空比W

#if(SEL_V_LED_R == 3)
#define SET_USER_PWM_DUTY_R	20		//100	//占空比R
#elif(SEL_V_LED_R == 4)
#define SET_USER_PWM_DUTY_R	20		//100	//占空比R
#elif(SEL_V_LED_R == 6)
#define SET_USER_PWM_DUTY_R	20		//100	//占空比R
#endif

//满电高亮模式 >3.9V
#define SET_USER_PWM_DUTY_W_LV1_H_PHS1		1500	//起始
#define SET_USER_PWM_DUTY_W_LV1_H_PHS2		1950	//逐渐升高
#define SET_USER_PWM_DUTY_W_LV1_H_PHS3		1100	//逐渐降低

#define SET_USER_PWM_DUTY_W_LV2_H_PHS1		950		//起始
#define SET_USER_PWM_DUTY_W_LV2_H_PHS2		800		//逐渐降低

#define SET_USER_PWM_DUTY_W_LV3_H_PHS1		350//20//55

#if(SEL_V_LED_R == 3)
#define SET_USER_PWM_DUTY_R_LV1_H_PHS1		12//4//20//40
#define SET_USER_PWM_DUTY_R_LV2_H_PHS1		8//3//35
#elif(SEL_V_LED_R == 4)
#define SET_USER_PWM_DUTY_R_LV1_H_PHS1		18//4//40
#define SET_USER_PWM_DUTY_R_LV2_H_PHS1		12//3//35
#elif(SEL_V_LED_R == 6)
#define SET_USER_PWM_DUTY_R_LV1_H_PHS1		4//4//20//40
#define SET_USER_PWM_DUTY_R_LV2_H_PHS1		3//3//35
#endif

//普通模式 3.7V-3.9V
#define SET_USER_PWM_DUTY_W_LV1_M_PHS1		780//35//70
#define SET_USER_PWM_DUTY_W_LV2_M_PHS1		590//30//65
#define SET_USER_PWM_DUTY_W_LV3_M_PHS1		190//20//55

#if(SEL_V_LED_R == 3)
#define SET_USER_PWM_DUTY_R_LV1_M_PHS1		15//4//20//40
#define SET_USER_PWM_DUTY_R_LV2_M_PHS1		10//3//35
#elif(SEL_V_LED_R == 4)
#define SET_USER_PWM_DUTY_R_LV1_M_PHS1		18//4//20//40
#define SET_USER_PWM_DUTY_R_LV2_M_PHS1		12//3//35
#elif(SEL_V_LED_R == 6)
#define SET_USER_PWM_DUTY_R_LV1_M_PHS1		4//4//20//40
#define SET_USER_PWM_DUTY_R_LV2_M_PHS1		3//3//35
#endif


//低电模式 <3.7V
#define SET_USER_PWM_DUTY_W_LV1_L_PHS1		700//35//70
#define SET_USER_PWM_DUTY_W_LV2_L_PHS1		450//30//65
#define SET_USER_PWM_DUTY_W_LV3_L_PHS1		180//20//55

#if(SEL_V_LED_R == 3)
#define SET_USER_PWM_DUTY_R_LV1_L_PHS1		18//4//20//40
#define SET_USER_PWM_DUTY_R_LV2_L_PHS1		13//3//35
#elif(SEL_V_LED_R == 4)
#define SET_USER_PWM_DUTY_R_LV1_L_PHS1		18//4//20//40
#define SET_USER_PWM_DUTY_R_LV2_L_PHS1		12//3//35
#elif(SEL_V_LED_R == 6)
#define SET_USER_PWM_DUTY_R_LV1_L_PHS1		4//4//20//40
#define SET_USER_PWM_DUTY_R_LV2_L_PHS1		3//3//35
#endif

#endif

#define PWM_CH_BOOST	PA4_CHANNEL
#define PWM_CH_LED_R	PB3_CHANNEL
#define PWM_CH_LED_W	PB4_CHANNEL

#define SET_PWM_BOOST_DUTY_MAX		6

extern u16 pwmBoostDuty,pwmLedRDuty,pwmLedWDuty;

void user_setPwm(u8 channel,u8 pwm_duty); //频率固定

#endif

