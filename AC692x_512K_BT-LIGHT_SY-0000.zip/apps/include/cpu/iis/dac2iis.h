#ifndef IIS2DAC_H
#define IIS2DAC_H
#include "sdk_cfg.h"
void dac2iis_src_open_ctrl(int open_flag);
void dac2iis_init(void);
void dac2iis_sr(u16 rate);

#endif



