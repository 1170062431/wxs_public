
#ifndef _USER_AD_H_
#define _USER_AD_H_

#include "user_project.h"

u16 user_getAD(u32 channel);

#endif

