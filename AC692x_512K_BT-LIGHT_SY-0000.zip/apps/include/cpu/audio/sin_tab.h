#ifndef _SIN_TAB_H_
#define _SIN_TAB_H_

#include "typedef.h"

extern const u8 sin_32k[];
extern const short sin_441k[441];

void dac_debug(s16 *dac_buf);

#endif/* _SIN_TAB_H_ */
