#ifndef _UART_USER_
#define _UART_USER_

#include "sdk_cfg.h"
#include "uart.h"
#include "typedef.h"

#define DEBUG_UART   (DEBUG_UART_SEL&0xF0)


#endif

