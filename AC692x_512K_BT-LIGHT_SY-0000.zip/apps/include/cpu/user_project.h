
#ifndef _USER_PROJECT_H_
#define _USER_PROJECT_H_

#define USER_TEST_EN		0
#define USER_LRC_LYRICS_EN	0	//LRC歌词显示

#define USER_PRO_EN			1

#define SEL_V_LED_R			4	//3/4/6, 3=3V,6=6V

#define SEL_IC_AC6925B		1

#if SEL_IC_AC6925B
//PC
#define IO_TestLed1_in		(JL_PORTC->IN & BIT(5))
#define IO_TestLed1_out		(JL_PORTC->OUT & BIT(5))
#define SET_TestLed1_in		JL_PORTC->DIR |=  BIT(5)
#define SET_TestLed1_out		JL_PORTC->DIR &= ~BIT(5)
#define IO_TestLed1_set		JL_PORTC->OUT |=  BIT(5)
#define IO_TestLed1_clr		JL_PORTC->OUT &= ~BIT(5)
#define IO_TestLed1_puOn		JL_PORTC->PU  |=  BIT(5)
#define IO_TestLed1_puOff	JL_PORTC->PU  &= ~BIT(5)
#define IO_TestLed1_pdOn		JL_PORTC->PD  |=  BIT(5)
#define IO_TestLed1_pdOff	JL_PORTC->PD  &= ~BIT(5)

#define IO_adVin_in			(JL_PORTC->IN & BIT(4))
#define IO_adVin_out		(JL_PORTC->OUT & BIT(4))
#define SET_adVin_in		JL_PORTC->DIR |=  BIT(4)
#define SET_adVin_out		JL_PORTC->DIR &= ~BIT(4)
#define IO_adVin_set		JL_PORTC->OUT |=  BIT(4)
#define IO_adVin_clr		JL_PORTC->OUT &= ~BIT(4)
#define IO_adVin_puOn		JL_PORTC->PU  |=  BIT(4)
#define IO_adVin_puOff		JL_PORTC->PU  &= ~BIT(4)
#define IO_adVin_pdOn		JL_PORTC->PD  |=  BIT(4)
#define IO_adVin_pdOff		JL_PORTC->PD  &= ~BIT(4)

#define IO_adLed_in		(JL_PORTC->IN & BIT(3))
#define IO_adLed_out		(JL_PORTC->OUT & BIT(3))
#define SET_adLed_in		JL_PORTC->DIR |=  BIT(3)
#define SET_adLed_out		JL_PORTC->DIR &= ~BIT(3)
#define IO_adLed_set		JL_PORTC->OUT |=  BIT(3)
#define IO_adLed_clr		JL_PORTC->OUT &= ~BIT(3)
#define IO_adLed_puOn		JL_PORTC->PU  |=  BIT(3)
#define IO_adLed_puOff		JL_PORTC->PU  &= ~BIT(3)
//usb
#define IO_led1_in			USB_DM_IN
#define SET_led1_in			USB_DM_DIR(1)
#define SET_led1_out		USB_DM_DIR(0)
#define IO_led1_set			USB_DM_OUT(1)
#define IO_led1_clr			USB_DM_OUT(0)
#define IO_led1_puOn		USB_DM_PU(1)
#define IO_led1_puOff		USB_DM_PU(0)

#define IO_led2_in			USB_DP_IN
#define SET_led2_in			USB_DP_DIR(1)
#define SET_led2_out		USB_DP_DIR(0)
#define IO_led2_set			USB_DP_OUT(1)
#define IO_led2_clr			USB_DP_OUT(0)
#define IO_led2_puOn		USB_DP_PU(1)
#define IO_led2_puOff		USB_DP_PU(0)
//PA
#define IO_pwmBoost_in		(JL_PORTA->IN & BIT(0))
#define IO_pwmBoost_out		(JL_PORTA->OUT & BIT(0))
#define SET_pwmBoost_in		JL_PORTA->DIR |=  BIT(0)
#define SET_pwmBoost_out	JL_PORTA->DIR &= ~BIT(0)
#define IO_pwmBoost_set		JL_PORTA->OUT |=  BIT(0)
#define IO_pwmBoost_clr		JL_PORTA->OUT &= ~BIT(0)
#define IO_pwmBoost_puOn	JL_PORTA->PU  |=  BIT(0)
#define IO_pwmBoost_puOff	JL_PORTA->PU  &= ~BIT(0)

#define IO_muteEn_in		(JL_PORTA->IN & BIT(3))
#define IO_muteEn_out		(JL_PORTA->OUT & BIT(3))
#define SET_muteEn_in		JL_PORTA->DIR |=  BIT(3)
#define SET_muteEn_out		JL_PORTA->DIR &= ~BIT(3)
#define IO_muteEn_set		JL_PORTA->OUT |=  BIT(3)
#define IO_muteEn_clr		JL_PORTA->OUT &= ~BIT(3)
#define IO_muteEn_puOn		JL_PORTA->PU  |=  BIT(3)
#define IO_muteEn_puOff		JL_PORTA->PU  &= ~BIT(3)
//PB
#define IO_poweronEn_in		(JL_PORTB->IN & BIT(0))
#define IO_poweronEn_out		(JL_PORTB->OUT & BIT(0))
#define SET_poweronEn_in	JL_PORTB->DIR |=  BIT(0)
#define SET_poweronEn_out	JL_PORTB->DIR &= ~BIT(0)
#define IO_poweronEn_set	JL_PORTB->OUT |=  BIT(0)
#define IO_poweronEn_clr	JL_PORTB->OUT &= ~BIT(0)
#define IO_poweronEn_puOn	JL_PORTB->PU  |=  BIT(0)
#define IO_poweronEn_puOff	JL_PORTB->PU  &= ~BIT(0)

#define IO_adKey_in			(JL_PORTB->IN & BIT(1))
#define IO_adKey_out		(JL_PORTB->OUT & BIT(1))
#define SET_adKey_in		JL_PORTB->DIR |=  BIT(1)
#define SET_adKey_out		JL_PORTB->DIR &= ~BIT(1)
#define IO_adKey_set		JL_PORTB->OUT |=  BIT(1)
#define IO_adKey_clr		JL_PORTB->OUT &= ~BIT(1)
#define IO_adKey_puOn		JL_PORTB->PU  |=  BIT(1)
#define IO_adKey_puOff		JL_PORTB->PU  &= ~BIT(1)
#define IO_adKey_pdOn		JL_PORTB->PD  |=  BIT(1)
#define IO_adKey_pdOff		JL_PORTB->PD  &= ~BIT(1)

#define IO_pwmLedR_in		(JL_PORTB->IN & BIT(3))
#define IO_pwmLedR_out		(JL_PORTB->OUT & BIT(3))
#define SET_pwmLedR_in		JL_PORTB->DIR |=  BIT(3)
#define SET_pwmLedR_out		JL_PORTB->DIR &= ~BIT(3)
#define IO_pwmLedR_set		JL_PORTB->OUT |=  BIT(3)
#define IO_pwmLedR_clr		JL_PORTB->OUT &= ~BIT(3)
#define IO_pwmLedR_puOn		JL_PORTB->PU  |=  BIT(3)
#define IO_pwmLedR_puOff	JL_PORTB->PU  &= ~BIT(3)

#define IO_pwmLedW_in		(JL_PORTB->IN & BIT(4))
#define IO_pwmLedW_out		(JL_PORTB->OUT & BIT(4))
#define SET_pwmLedW_in		JL_PORTB->DIR |=  BIT(4)
#define SET_pwmLedW_out		JL_PORTB->DIR &= ~BIT(4)
#define IO_pwmLedW_set		JL_PORTB->OUT |=  BIT(4)
#define IO_pwmLedW_clr		JL_PORTB->OUT &= ~BIT(4)
#define IO_pwmLedW_puOn		JL_PORTB->PU  |=  BIT(4)
#define IO_pwmLedW_puOff	JL_PORTB->PU  &= ~BIT(4)

#define IO_btStaLedN_in		(JL_PORTB->IN & BIT(5))
#define IO_btStaLedN_out	(JL_PORTB->OUT & BIT(5))
#define SET_btStaLedN_in	JL_PORTB->DIR |=  BIT(5)
#define SET_btStaLedN_out	JL_PORTB->DIR &= ~BIT(5)
#define IO_btStaLedN_set	JL_PORTB->OUT |=  BIT(5)
#define IO_btStaLedN_clr	JL_PORTB->OUT &= ~BIT(5)
#define IO_btStaLedN_puOn	JL_PORTB->PU  |=  BIT(5)
#define IO_btStaLedN_puOff	JL_PORTB->PU  &= ~BIT(5)
#endif	//#if SEL_IC_AC6925B

#define SET_AD_KEY_MAX		1023
#define SET_AD_KEY_LED		639		//1023 / 3.3V * (3.7V-0.7V) / 3.2K * 2.2K
#define SET_AD_KEY_BT		259		//1023 / 3.3V * (3.7V-0.7V) / 7.9K * 2.2K
#define SET_AD_KEY_NON		0

#if 0
#define SET_DUTY_LED_W_LV1_MAX		230
#define SET_DUTY_LED_W_LV2_MAX		200
#define SET_DUTY_LED_W_LV3_MAX		120
#define SET_DUTY_LED_R_LV1_MAX		220
#define SET_DUTY_LED_R_LV2_MAX		180

#define SET_DUTY_LED_W_LV1_DEFAULT	200
#define SET_DUTY_LED_W_LV2_DEFAULT	170
#define SET_DUTY_LED_W_LV3_DEFAULT	100
#define SET_DUTY_LED_R_LV1_DEFAULT	155
#define SET_DUTY_LED_R_LV2_DEFAULT	105
#endif

enum KEY
{
	KEY_BEGIN = 0,
	KEY_NON,
	KEY_LED,
	KEY_BT,
	KEY_END,
};

#define SET_AD_LED_W_LV1	4
#define SET_AD_LED_W_LV2	3
#define SET_AD_LED_W_LV3	2
#define SET_AD_LED_R_LV1	3
#define SET_AD_LED_R_LV2	2

enum MODE
{
	MODE_BEGIN = 0,
	MODE_POWEROFF,
	MODE_LED_W_LV1,
	MODE_LED_W_LV2,
	MODE_LED_W_LV3,
	MODE_LED_R_LV1,
	MODE_LED_R_LV2,
	MODE_END,
};
enum BT_STATA
{
	BT_STATA_BEGIN = 0,
	BT_STATA_IDEL,
	BT_STATA_SCAN,
	BT_STATA_CONNECT,
	BT_STATA_PLAY_MISIC,
	BT_STATA_END,
};

#define SET_BATTERY_LEVEL_3V9	390
#define SET_BATTERY_LEVEL_3V7	370

#define POWER_LEVEL_H	3
#define POWER_LEVEL_M	2
#define POWER_LEVEL_L	1

#define SET_VBAT_LEVEL1_5		340
#define SET_VBAT_LEVEL2_25		355
#define SET_VBAT_LEVEL3_50		365
#define SET_VBAT_LEVEL4_75		375
#define SET_VBAT_LEVEL5_100		395

#define SET_VBAT_COMP_TIME		250	//1s=500

extern u8 vLevel;
extern u8 powerLevel;
extern u8 mode,btStata;
extern u16 T_ledOn_s;
extern u8 F_powerOn,F_powerOff;

extern u8 F_isVin;		//充电插入状态,0=无充电器插入 ，2=充电器插入

void user_io_init();
void user_getAdLed();
void user_keyScan();


#endif

