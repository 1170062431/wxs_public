#ifndef __CARD_READER_
#define __CARD_READER_

sUSB_DEV_IO *get_card_read_io(DEV_TYPE dev_type);
#endif
