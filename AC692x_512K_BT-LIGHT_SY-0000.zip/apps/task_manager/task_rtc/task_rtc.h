#ifndef __TASK_RTC_H_
#define __TASK_RTC_H_
#include "typedef.h"
#include "task_manager.h"

extern const TASK_APP task_rtc_info;
#endif
