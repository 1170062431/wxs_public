#ifndef _TASK_REC_
#define _TASK_REC_
#include "typedef.h"
#include "task_manager.h"

extern const TASK_APP task_rec_info;


#endif
