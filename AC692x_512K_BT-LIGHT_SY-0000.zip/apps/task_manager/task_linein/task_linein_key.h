#ifndef __TASK_LINEIN_KEY_H__
#define __TASK_LINEIN_KEY_H__

#include "key.h"

extern const KEY_REG task_linein_key;

#endif// __TASK_LINEIN_KEY_H__
