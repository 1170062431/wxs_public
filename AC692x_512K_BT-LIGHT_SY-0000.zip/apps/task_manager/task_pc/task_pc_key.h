#ifndef __TASK_PC_KEY_H__
#define __TASK_PC_KEY_H__
#include "key.h"

extern const KEY_REG task_pc_key;

#endif// __TASK_PC_KEY_H__
