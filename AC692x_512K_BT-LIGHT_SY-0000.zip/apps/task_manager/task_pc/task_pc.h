#ifndef __TASK_PC_H_
#define __TASK_PC_H_
#include "typedef.h"
#include "task_manager.h"

extern const TASK_APP task_pc_info;
void pc_task_test();
#endif
