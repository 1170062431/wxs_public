#ifndef __TASK_MUSIC_H__
#define __TASK_MUSIC_H__
#include "typedef.h"
#include "task_manager.h"

extern const TASK_APP task_music_info;


#if 0
#define MUSIC_TASK_NAME		"MusicTask"
// struct task_info music_task_info;
#endif
#endif//__TASK_MUSIC_H__

