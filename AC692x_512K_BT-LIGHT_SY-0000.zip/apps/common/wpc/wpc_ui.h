#ifndef __WPC_UI_H__
#define __WPC_UI_H__

#include "typedef.h"
#include "wpc_api.h"
#include "led_ctrl.h"


void ui_set(UI_CMD ui_cmd);

#endif

