#include "sdk_cfg.h"
#include "led.h"
#include "timer.h"
#include "clock_api.h"
#include "common.h"
#include "board_init.h"
#include "bluetooth/bt_led.h"
#include "key.h"
#include "adc_api.h"
#include "audio/dac_api.h"
#include "task_bt.h"
#include "avctp_user.h"
#include "power.h"
#include "warning_tone.h"
#include "power_manage_api.h"
#include "msg.h"
#include "bt_tws.h"
#include "user_project.h"
#include "user_pwm.h"
#include "user_ad.h"

u8 vLevel;
u8 powerLevel;
u8 mode,btStata;
u16 T_ledOn_s;
u8 F_powerOn,F_powerOff;

u8 F_isVin = 0;		//充电插入状态,0=无充电器插入，	1=充电器插入

void user_io_init()
{
	static u8 F_init = 0;

	if(F_init)
		return;
	
#if USER_TEST_EN		//调试时使用
	SET_TestLed1_in;
	IO_TestLed1_puOff;
	
	SET_adVin_out;
	IO_adVin_clr;
#else
	SET_TestLed1_in;
	IO_TestLed1_puOn;
	
	SET_adVin_in;
	IO_adVin_puOff;
	IO_adVin_pdOn;
#endif

	SET_adLed_in;
	IO_adLed_puOff;
		
//---------------------
//---------------------
#ifdef __DEBUG			//调试时使用
//	备用输出
	SET_led1_in;
	IO_led1_puOn;

	SET_led2_out;
	IO_led2_set;
#else
	SET_led1_out;
	IO_led1_clr;

	SET_led2_out;
	IO_led2_clr;
#endif
//---------------------
//---------------------

	SET_pwmBoost_out;
	IO_pwmBoost_clr;

	SET_muteEn_out;
	IO_muteEn_set;

	SET_poweronEn_out;
	IO_poweronEn_set;

	SET_adKey_in;
	IO_adKey_puOff;

	SET_pwmLedR_out;
	IO_pwmLedR_clr;

	SET_pwmLedW_out;
	IO_pwmLedW_clr;

	SET_btStaLedN_out;
	IO_btStaLedN_set;

	mode = MODE_POWEROFF;
	
	#if USER_TEST_EN
	btStata = BT_STATA_SCAN;
	#else
	btStata = BT_STATA_IDEL;
	#endif
	T_ledOn_s = 0;
	powerLevel = POWER_LEVEL_L;
	vLevel = 0;
	F_powerOn = 0;
	F_powerOff = 0;
	
	F_init = 1;
}

#if 1
void user_vLedDisp()		//2ms
{
	static u8 F_vinit = 0;
	static u16 T_2ms = 0;
	static u16 comp = SET_VBAT_COMP_TIME;		//电量高了加1，低了减1;加到comp+n,vLevel+1;减到0,vLevel-1;然后回复初始值
	static u8 index = 0;
	u16 val = 0 ;
	
	static u16 adVbatMax=0,adVbatMin=1023;
	static u8 adCnt=0;
//	return;

	val = adc_value[R_AD_CH_PC4];
	if(val>50)
		F_isVin = 1;
	else
		F_isVin = 0;

//	if(IO_TestLed1_in || IO_TestLed2_in)
	{
		T_2ms++;
		if(T_2ms == 5)
		{
			T_2ms = 0;

			val = get_battery_level();
			
			if(val>0 && val<500)
			{
				val += pwmLedWDuty/100;
				/*
				if(pwmLedWDuty > 1500)
					val += 60;
				else if(pwmLedWDuty > 1400)
					val += 55;
				else if(pwmLedWDuty > 1200)
					val += 50;
				else if(pwmLedWDuty > 1100)
					val += 45;
				else if(pwmLedWDuty > 800)
					val += 30;
				*/
				#if 0	//fast Vbat
				if(!F_vinit)
				{
					if(val >= SET_VBAT_LEVEL5_100)			//lv5
					{
						if(vLevel >= 5)
							F_vinit = 1;
						vLevel = 5;
					}
					else if(val >= SET_VBAT_LEVEL4_75+2)	//lv4
					{
						if(vLevel >= 4)
							F_vinit = 1;
						vLevel = 4;
					}
					else if(val >= SET_VBAT_LEVEL3_50+2)	//lv3
					{
						if(vLevel >= 3)
							F_vinit = 1;
						vLevel = 3;
					}
					else if(val >= SET_VBAT_LEVEL2_25+2)	//lv2
					{
						if(vLevel >= 2)
							F_vinit = 1;
						vLevel = 2;
					}
					else if(val >= SET_VBAT_LEVEL1_5+2)		//lv1
					{
						if(vLevel >= 1)
							F_vinit = 1;
						vLevel = 1;
					}
				}
				#endif
				
				switch(vLevel)
				{
				case 0:
					if(val>SET_VBAT_LEVEL1_5+5)
						comp++;
					else
						comp = SET_VBAT_COMP_TIME;
					break;
				case 1:
					if(val>SET_VBAT_LEVEL2_25+5)
						comp++;
					else if(val<SET_VBAT_LEVEL1_5)
						comp--;
					else
						comp = SET_VBAT_COMP_TIME;
					break;
				case 2:
					if(val>SET_VBAT_LEVEL3_50+5)
						comp++;
					else if(val<SET_VBAT_LEVEL2_25)
						comp--;
					else
						comp = SET_VBAT_COMP_TIME;
					break;
				case 3:
					if(val>SET_VBAT_LEVEL4_75+5)
						comp++;
					else if(val<SET_VBAT_LEVEL3_50)
						comp--;
					else
						comp = SET_VBAT_COMP_TIME;
					break;
				case 4:
					if(val>SET_VBAT_LEVEL5_100+5)
						comp++;
					else if(val<SET_VBAT_LEVEL4_75)
						comp--;
					else
						comp = SET_VBAT_COMP_TIME;
					break;
				case 5:
					if(val<390)
						comp--;
					else
						comp = SET_VBAT_COMP_TIME;
					break;
				default:
					vLevel = 0;
					break;
				}
				
			//	if((comp == SET_VBAT_COMP_TIME<<1)&&(F_isVin))
				if(comp == SET_VBAT_COMP_TIME+50)
				{
					vLevel++;
					comp = SET_VBAT_COMP_TIME;
				}
				else if(comp == 0)
				{
					vLevel--;
					comp = SET_VBAT_COMP_TIME;
				}
			}
		}

		#if 1
		SET_led1_in;
		IO_led1_puOff;
		
		SET_led2_in;
		IO_led2_puOff;
		
		switch(index)
		{
		case 0:
			//led1 on
			if(F_isVin && vLevel<=1)
			{
				if(sys_global_value.t0_cnt1/500%2)
				{
					SET_led1_out;
					IO_led1_set;
				}
			}
			else if(vLevel>0 || sys_global_value.t0_cnt1/250%2)
			{
				SET_led1_out;
				IO_led1_set;
			}

			//led2 on
			if(F_isVin && vLevel==2)
			{
				if(sys_global_value.t0_cnt1/500%2)
				{
					SET_led2_out;
					IO_led2_set;
				}
			}
			else if(vLevel>1)
			{
				SET_led2_out;
				IO_led2_set;
			}
			index++;
			break;
		case 1:
			//led3 on
			if(F_isVin && vLevel==3)
			{
				if(sys_global_value.t0_cnt1/500%2)
				{
					SET_led1_out;
					IO_led1_clr;
				}
			}
			else if(vLevel>2)
			{
				SET_led1_out;
				IO_led1_clr;
			}
			
			//led4 on
			if(F_isVin && vLevel==4)
			{
				if(sys_global_value.t0_cnt1/500%2)
				{
					SET_led2_out;
					IO_led2_clr;
				}
			}
			else if(vLevel>3)
			{
				SET_led2_out;
				IO_led2_clr;
			}
			index = 0;
			break;
		default:
			index = 0;
			break;
		}
		#endif
		
	}
	/*
	else
	{
		SET_led1_in;
		IO_led1_puOff;
		
		SET_led2_in;
		IO_led2_puOff;
	}
	*/
}

void user_getAdLed()		//10ms
{
	static u8 T_10ms = 0;
	static u8 pwmDutyBackup = 0;
	static u16 compBuff = 0xAAAA;
	u16 adBuf = 0,adNum = 0;
	u16 adSum = 0,adMin = 1024,adMax = 0;
	u16 adBat;
	
	adBuf = adc_value[R_AD_CH_PC3];
	#if 0
	for(adNum=0;adNum<10;adNum++)
	{
		adBuf = user_getAD(AD_CH_PC4);
		adSum += adBuf;
		
		if(adBuf < adMin)
			adMin = adBuf;
		if(adBuf > adMax)
			adMax = adBuf;
	}
	adSum = adSum-adMin-adMax;
	adBuf = adSum>>3;
	#endif

//	if(adBuf > 70)
//		pwmLedWDuty -= 5;
	
//	if(!adBuf && (pwmBoostDuty >= SET_PWM_BOOST_DUTY_MAX))
//		mode = MODE_POWEROFF;
	
	if(mode == MODE_POWEROFF)
	{
		pwmBoostDuty = 0;
		IO_pwmLedW_clr;
		IO_pwmLedR_clr;
		T_10ms = 0;
		T_ledOn_s = 0;
		return;
	}
	
	T_10ms++;
	if(T_10ms == 100)
	{
		T_10ms = 0;
	
		if(T_ledOn_s < 60000)
			T_ledOn_s++;
	}
	
	if(T_10ms%20 == 0)
	{
		if(powerLevel == POWER_LEVEL_H)
		{
			if(mode == MODE_LED_W_LV1)
			{
				if(T_ledOn_s<=40 && pwmLedWDuty<SET_USER_PWM_DUTY_W_LV1_H_PHS2 && pwmLedWDuty>=SET_USER_PWM_DUTY_W_LV1_H_PHS1)
					pwmLedWDuty += 3;
				else if(T_ledOn_s>40 && pwmLedWDuty>SET_USER_PWM_DUTY_W_LV1_H_PHS3)
					pwmLedWDuty -= 3;
			}
			else if((mode == MODE_LED_W_LV2)&&(T_ledOn_s%8 == 0))
			{
				if(T_ledOn_s>60 && pwmLedWDuty>SET_USER_PWM_DUTY_W_LV2_H_PHS2)
					pwmLedWDuty--;
			}
		}
		else if(T_ledOn_s > 200)
		{
			adBat = get_battery_level();
			if(adBat < SET_BATTERY_LEVEL_3V7)
			{
				powerLevel = POWER_LEVEL_L;
				switch(mode)
				{
				case MODE_LED_W_LV1:
					if(pwmLedWDuty > SET_USER_PWM_DUTY_W_LV1_L_PHS1)
						pwmLedWDuty--;
					break;
				case MODE_LED_W_LV2:
					if(pwmLedWDuty > SET_USER_PWM_DUTY_W_LV2_L_PHS1)
						pwmLedWDuty--;
					break;
				case MODE_LED_W_LV3:
					if(pwmLedWDuty > SET_USER_PWM_DUTY_W_LV3_L_PHS1)
						pwmLedWDuty--;
					break;
				default:
					break;
				}
			}
			else if(adBat < SET_BATTERY_LEVEL_3V9)
			{
				powerLevel = POWER_LEVEL_M;
				switch(mode)
				{
				case MODE_LED_W_LV1:
					if(pwmLedWDuty > SET_USER_PWM_DUTY_W_LV1_M_PHS1)
						pwmLedWDuty--;
					else if(pwmLedWDuty < SET_USER_PWM_DUTY_W_LV1_M_PHS1)
						pwmLedWDuty++;
					break;
				case MODE_LED_W_LV2:
					if(pwmLedWDuty > SET_USER_PWM_DUTY_W_LV2_M_PHS1)
						pwmLedWDuty--;
 					else if(pwmLedWDuty < SET_USER_PWM_DUTY_W_LV2_M_PHS1)
						pwmLedWDuty++;
					break;
				case MODE_LED_W_LV3:
					if(pwmLedWDuty > SET_USER_PWM_DUTY_W_LV3_M_PHS1)
						pwmLedWDuty--;
 					else if(pwmLedWDuty < SET_USER_PWM_DUTY_W_LV3_M_PHS1)
						pwmLedWDuty++;
					break;
				default:
					break;
				}
			}
			else
			{
				powerLevel = POWER_LEVEL_H;
				switch(mode)
				{
				case MODE_LED_W_LV1:
					if(pwmLedWDuty < SET_USER_PWM_DUTY_W_LV1_H_PHS3)
						pwmLedWDuty++;
					break;
				case MODE_LED_W_LV2:
					if(pwmLedWDuty < SET_USER_PWM_DUTY_W_LV2_H_PHS2)
						pwmLedWDuty++;
					break;
				case MODE_LED_W_LV3:
					if(pwmLedWDuty < SET_USER_PWM_DUTY_W_LV3_H_PHS1)
						pwmLedWDuty++;
					break;
				default:
					break;
				}
			}
		}
	}
	
	switch(mode)
	{
	case MODE_LED_W_LV1:
		if(adBuf > SET_AD_LED_W_LV1+1)
			compBuff = (compBuff<<1)|1;
		else if(adBuf < SET_AD_LED_W_LV1-1)
			compBuff = (compBuff<<1)|0;
		else
			compBuff = 0xAAAA;
		break;
	case MODE_LED_W_LV2:
		if(adBuf > SET_AD_LED_W_LV2+1)
			compBuff = (compBuff<<1)|1;
		else if(adBuf < SET_AD_LED_W_LV2-1)
			compBuff = (compBuff<<1)|0;
		else
			compBuff = 0xAAAA;
		break;
	case MODE_LED_W_LV3:
		if(adBuf > SET_AD_LED_W_LV3+1)
			compBuff = (compBuff<<1)|1;
		else if(adBuf < SET_AD_LED_W_LV3-1)
			compBuff = (compBuff<<1)|0;
		else
			compBuff = 0xAAAA;
		break;
	case MODE_LED_R_LV1:
		if(adBuf > SET_AD_LED_R_LV1+1)
			compBuff = (compBuff<<1)|1;
		else if(adBuf < SET_AD_LED_R_LV1-1)
			compBuff = (compBuff<<1)|0;
		else
			compBuff = 0xAAAA;
		break;
	case MODE_LED_R_LV2:
		if(sys_global_value.t0_cnt1 / 125 % 2)
		{
			#if 1
		//	pwmDutyBackup = pwmBoostDuty;
			IO_pwmBoost_clr;
			#endif

			pwmLedRDuty = 0;
			
			compBuff = 0xAAAA;
		}
		else
		{
			#if 1
		//	if(!pwmBoostDuty)
		//		pwmBoostDuty = 1;//pwmDutyBackup;
			#if (SEL_V_LED_R > 3)
			IO_pwmBoost_set;
			#endif
			#endif
			
			pwmLedRDuty = SET_USER_PWM_DUTY_R_LV2_L_PHS1;
			
			if(adBuf > SET_AD_LED_R_LV2+1)
				compBuff = (compBuff<<1)|1;
			else if(adBuf < SET_AD_LED_R_LV2-1)
				compBuff = (compBuff<<1)|0;
			else
				compBuff = 0xAAAA;
		}
		break;
	default:break;
	}
	
	#if 0	
	if((compBuff == 0xFFFF) && pwmBoostDuty)
		pwmBoostDuty--;
	else if((compBuff == 0x0000) && (pwmBoostDuty<SET_PWM_BOOST_DUTY_MAX))
		pwmBoostDuty++;
	#endif
	
	#if 0	//del
	if(mode == MODE_POWEROFF)
	{
		pwmBoostDuty = 0;
		pwmLedWDuty = 0;
		pwmLedRDuty = 0;
		return;
	}
	switch(mode)
	{
	case MODE_LED_W_LV1:
		pwmBoostDuty = 4;
		if((adBuf > SET_AD_LED_W_LV1)&&(pwmLedWDuty))
			pwmLedWDuty--;
		else if((adBuf < SET_AD_LED_W_LV1)&&(pwmLedWDuty<SET_DUTY_LED_W_LV1_MAX))
			pwmLedWDuty++;
		break;
	case MODE_LED_W_LV2:
		pwmBoostDuty = 4;
		if((adBuf > SET_AD_LED_W_LV2)&&(pwmLedWDuty))
			pwmLedWDuty--;
		else if((adBuf < SET_AD_LED_W_LV2)&&(pwmLedWDuty<SET_DUTY_LED_W_LV2_MAX))
			pwmLedWDuty++;
		break;
	case MODE_LED_W_LV3:
		pwmBoostDuty = 3;
		if((adBuf > SET_AD_LED_W_LV3)&&(pwmLedWDuty))
			pwmLedWDuty--;
		else if((adBuf < SET_AD_LED_W_LV3)&&(pwmLedWDuty<SET_DUTY_LED_W_LV3_MAX))
			pwmLedWDuty++;
		break;
	case MODE_LED_R_LV1:
		pwmBoostDuty = 4;
		if((adBuf > SET_AD_LED_R_LV1)&&(pwmLedRDuty))
			pwmLedRDuty--;
		else if((adBuf < SET_AD_LED_R_LV1)&&(pwmLedRDuty<SET_DUTY_LED_R_LV1_MAX))
			pwmLedRDuty++;
		break;
	case MODE_LED_R_LV2:
		pwmBoostDuty = 4;
		if(sys_global_value.t0_cnt1 / 125 % 2)
		{
			pwmDutyBackup = pwmLedRDuty;
			pwmLedRDuty = 0;
		}
		else
		{
			if(!pwmLedRDuty)
				pwmLedRDuty = pwmDutyBackup;
			else
			{
				if((adBuf > SET_AD_LED_R_LV2)&&(pwmLedRDuty))
					pwmLedRDuty--;
				else if((adBuf < SET_AD_LED_R_LV2)&&(pwmLedRDuty<SET_DUTY_LED_R_LV2_MAX))
					pwmLedRDuty++;
			}
		}
		break;
	default:break;
	}
	#endif
	
	USER_SET_PWM3_PWM(pwmLedWDuty);
}

void user_btStataScan()	//50ms
{
	static u8 T_btStataLedOn_50ms = 0;
	u8 stata = 0, temp = 0;;

	stata = get_bt_connect_status();
	switch(stata)
	{
	case BT_STATUS_INITING:          /*正在初始化*/
	case BT_STATUS_WAITINT_CONN:     /*等待连接*/
	case BT_STATUS_AUTO_CONNECTINT:  /*正在回连*/
		if(btStata == BT_STATA_IDEL)
			user_send_cmd_prepare(USER_CTRL_POWER_OFF, 0, NULL);
		else
			btStata = BT_STATA_SCAN;
		break;
	case BT_STATUS_TAKEING_PHONE:    /*正在电话*/
		break;
	case BT_STATUS_CONNECTING:       /*已连接，没有电话和音乐在活动*/
		btStata = BT_STATA_CONNECT;
		break;
	case BT_STATUS_PLAYING_MUSIC:    /*正在音乐*/
		btStata = BT_STATA_PLAY_MISIC;
		break;
	default:
		break;
	}

	temp = get_tone_status();
	if(!temp)
	{
		if(F_powerOn)
		{
			F_powerOn = 0;
			user_send_cmd_prepare(USER_CTRL_POWER_ON, 0, NULL);
		}
		else if(F_powerOff)
		{
			F_powerOff = 0;
  		//	user_send_cmd_prepare(USER_CTRL_POWER_OFF, 0, NULL);
			tone_play(TONE_POWER_OFF, 0);
		}
	}
	
	if((stata == BT_STATUS_PLAYING_MUSIC)||(!temp))
		IO_muteEn_clr;
	else
		IO_muteEn_set;
	
	switch(btStata)
	{
	case BT_STATA_IDEL:
	//	if(temp == 0)
	//		IO_muteEn_set;
	//	else
	//		IO_muteEn_clr;
		IO_btStaLedN_set;
		break;
	case BT_STATA_SCAN:
	//	IO_muteEn_clr;
		if(sys_global_value.t0_cnt1 / 125 % 2)
		{
			T_btStataLedOn_50ms = 5;
			IO_btStaLedN_set;
		}
		else if(T_btStataLedOn_50ms)
		{
			T_btStataLedOn_50ms--;
			IO_btStaLedN_clr;
		}
		else
			IO_btStaLedN_set;
		break;
	case BT_STATA_PLAY_MISIC:
	//	IO_muteEn_clr;
		if(sys_global_value.t0_cnt1 / 500 % 2)
		{
			T_btStataLedOn_50ms = 5;
			IO_btStaLedN_set;
		}
		else if(T_btStataLedOn_50ms)
		{
			T_btStataLedOn_50ms--;
			IO_btStaLedN_clr;
		}
		else
			IO_btStaLedN_set;
		break;
	case BT_STATA_CONNECT:
	//	IO_muteEn_clr;
		IO_btStaLedN_clr;
		break;
	default:
		break;
	}
	
}

void user_keyScan()		//20ms
{
	static u8 keyCode_ad = KEY_NON;
	static u16 adBuf = 0;
	static u16 temp;
	static u8 T_keyDown_20ms = 0;

//	adBuf = user_getAD(AD_CH_PB1);
	adBuf = adc_value[R_AD_CH_PB1];
//	log_printf("adBuf = %d",adBuf);
	
	if(adBuf < SET_AD_KEY_NON+50)
	{
		if((keyCode_ad == KEY_BT)&&(T_keyDown_20ms < 100)&&(T_keyDown_20ms > 2))
		{
			if(btStata == BT_STATA_PLAY_MISIC)
			{
				if(is_tws_device_slave()||is_1t2_connection())
					tws_cmd_send(MSG_TWS_PAUSE, 0);
				btStata = BT_STATA_CONNECT;
  				user_send_cmd_prepare(USER_CTRL_AVCTP_OPID_PAUSE, 0, NULL);
			}
			else if(btStata == BT_STATA_CONNECT)
			{
				if(is_tws_device_slave()||is_1t2_connection())
					tws_cmd_send(MSG_TWS_PLAY, 0);
				btStata = BT_STATA_PLAY_MISIC;
  				user_send_cmd_prepare(USER_CTRL_AVCTP_OPID_PLAY, 0, NULL);
			}
		}
		keyCode_ad = KEY_NON;
		T_keyDown_20ms = 0;
	}
	else if(adBuf < SET_AD_KEY_BT+150)
	{
		if(keyCode_ad != KEY_BT)
		{
			keyCode_ad = KEY_BT;
			T_keyDown_20ms = 0;
		}
		else if(T_keyDown_20ms < 100)
		{
			T_keyDown_20ms++;
		}
		else if(T_keyDown_20ms == 100)
		{
			temp = get_tone_status();
			if(temp)
				return;
			
			T_keyDown_20ms = 110;
			switch(btStata)
			{
			case BT_STATA_IDEL:
				btStata = BT_STATA_SCAN;
  			//	user_send_cmd_prepare(USER_CTRL_WRITE_SCAN_ENABLE, 0, NULL);
  			//	user_send_cmd_prepare(USER_CTRL_WRITE_CONN_ENABLE, 0, NULL);
				F_powerOn = 1;
				tone_play(TONE_POWER_ON, 0);
  			//	user_send_cmd_prepare(USER_CTRL_POWER_ON, 0, NULL);
				break;
			case BT_STATA_SCAN:
			case BT_STATA_PLAY_MISIC:
			case BT_STATA_CONNECT:
				btStata = BT_STATA_IDEL;
  			//	user_send_cmd_prepare(USER_CTRL_WRITE_SCAN_DISABLE, 0, NULL);
  			//	user_send_cmd_prepare(USER_CTRL_WRITE_CONN_DISABLE, 0, NULL);
  				F_powerOff = 1;
			//	tone_play(TONE_POWER_OFF, 0);
  				user_send_cmd_prepare(USER_CTRL_POWER_OFF, 0, NULL);
				break;
			default:
				break;
			}
		}
	}
	else if(adBuf < SET_AD_KEY_LED+150)
	{
		if(keyCode_ad != KEY_LED)
		{
			keyCode_ad = KEY_LED;
			T_keyDown_20ms = 0;
		}
		else if(T_keyDown_20ms < 2)
		{
			T_keyDown_20ms++;
		}
		else if(T_keyDown_20ms == 2)
		{
			T_keyDown_20ms = 3;

			#if 0
			switch(mode)
			{
				case MODE_POWEROFF:
					mode = MODE_LED_W_LV1;
					pwmLedWDuty = SET_DUTY_LED_W_LV1_DEFAULT;
					break;
				case MODE_LED_W_LV1:
					mode = MODE_LED_W_LV2;
					pwmLedWDuty = SET_DUTY_LED_W_LV2_DEFAULT;
					break;
				case MODE_LED_W_LV2:
					mode = MODE_LED_W_LV3;
					pwmLedWDuty = SET_DUTY_LED_W_LV3_DEFAULT;
					break;
				case MODE_LED_W_LV3:
					pwmLedWDuty = 0;
					mode = MODE_LED_R_LV1;
					pwmLedRDuty = SET_DUTY_LED_R_LV1_DEFAULT;
					break;
				case MODE_LED_R_LV1:
					sys_global_value.t0_cnt1 = 0;
					mode = MODE_LED_R_LV2;
					pwmLedRDuty = SET_DUTY_LED_R_LV2_DEFAULT;
					break;
				case MODE_LED_R_LV2:
					pwmLedRDuty = 0;
					mode = MODE_POWEROFF;
					break;
				default:
					pwmLedWDuty = 0;
					pwmLedRDuty = 0;
					mode = MODE_POWEROFF;
					break;
			}
			#endif

			if(T_ledOn_s < 60)
			{
				switch(mode)
				{
					case MODE_POWEROFF:
						temp = get_battery_level();
						if(temp > SET_BATTERY_LEVEL_3V9)
							powerLevel = POWER_LEVEL_H;
						else if(temp > SET_BATTERY_LEVEL_3V7)
							powerLevel = POWER_LEVEL_M;
						else if(temp < SET_BATTERY_LEVEL_3V7)
							powerLevel = POWER_LEVEL_L;
						
						mode = MODE_LED_W_LV1;
						IO_pwmBoost_set;
						if(powerLevel == POWER_LEVEL_H)
							pwmLedWDuty = SET_USER_PWM_DUTY_W_LV1_H_PHS1;
						else if(powerLevel == POWER_LEVEL_M)
							pwmLedWDuty = SET_USER_PWM_DUTY_W_LV1_M_PHS1;
						else
							pwmLedWDuty = SET_USER_PWM_DUTY_W_LV1_L_PHS1;
						break;
					case MODE_LED_W_LV1:
						mode = MODE_LED_W_LV2;
						if(powerLevel == POWER_LEVEL_H)
							pwmLedWDuty = SET_USER_PWM_DUTY_W_LV2_H_PHS1;
						else if(powerLevel == POWER_LEVEL_M)
							pwmLedWDuty = SET_USER_PWM_DUTY_W_LV2_M_PHS1;
						else
							pwmLedWDuty = SET_USER_PWM_DUTY_W_LV2_L_PHS1;
						break;
					case MODE_LED_W_LV2:
						mode = MODE_LED_W_LV3;
						if(powerLevel == POWER_LEVEL_H)
							pwmLedWDuty = SET_USER_PWM_DUTY_W_LV3_H_PHS1;
						else if(powerLevel == POWER_LEVEL_M)
							pwmLedWDuty = SET_USER_PWM_DUTY_W_LV3_M_PHS1;
						else
							pwmLedWDuty = SET_USER_PWM_DUTY_W_LV3_L_PHS1;
						break;
					case MODE_LED_W_LV3:
						
						#if(SEL_V_LED_R == 3)
						IO_pwmBoost_clr;
						#endif

						mode = MODE_LED_R_LV1;
						pwmLedWDuty = 0;
					//	IO_pwmLedR_set;
						pwmLedRDuty = SET_USER_PWM_DUTY_R_LV1_L_PHS1;
						break;
					case MODE_LED_R_LV1:
						sys_global_value.t0_cnt1 = 0;
						mode = MODE_LED_R_LV2;
					//	IO_pwmLedR_set;
						pwmLedRDuty = SET_USER_PWM_DUTY_R_LV2_L_PHS1;
						break;
					case MODE_LED_R_LV2:
						IO_pwmBoost_clr;
						mode = MODE_POWEROFF;
						pwmLedRDuty = 0;
						break;
					default:
						IO_pwmBoost_clr;
						mode = MODE_POWEROFF;
						pwmLedWDuty = 0;
					//	USER_SET_PWM3_PWM(0);
						pwmLedRDuty = 0;
						break;
				}
			}
			else
			{
				IO_pwmBoost_clr;
				mode = MODE_POWEROFF;
				pwmLedWDuty = 0;
			//	USER_SET_PWM3_PWM(0);
				pwmLedRDuty = 0;
			}
			T_ledOn_s = 0;
		}
	}
}
void user_dubugTest()			//1s
{
	u16 temp = 0;
	u16 adBuf,adNum,adSum = 0;
	
//	log_printf("歌词显示：bt_configs_user.c\n");
//	log_printf("ぁぃぅぇぉあいうえが\n");

//	user_send_cmd_prepare(USER_CTRL_AVCTP_OPID_GET_PLAY_TIME, 0, NULL);
	
	#if 0
	adBuf = get_battery_level();
	log_printf("get_battery_level = %d\n",adBuf);
	
	adBuf = adc_value[R_AD_CH_BT];
	log_printf("\nR_AD_CH_BT = %d\n",adBuf);

	adBuf = adc_value[R_AD_CH_VBAT];
	log_printf("R_AD_CH_VBAT = %d\n",adBuf);
	
	adBuf = adc_value[R_AD_CH_BT];
	log_printf("\nR_AD_CH_BT = %d\n",adBuf);

	adBuf = adc_value[R_AD_CH_VBAT];
	log_printf("R_AD_CH_VBAT = %d\n",adBuf);
	#endif

	#if 1
	adBuf = get_battery_level();
	if(adBuf>0 && adBuf<450)
	{
	//	adBuf += pwmLedWDuty/100;
	}
	log_printf("电量：%d\n",adBuf);
	log_printf("等级：%d\n",vLevel);

//	adBuf = adc_value[R_AD_CH_VBAT];
//	log_printf("VBAT：%d\n",adBuf);
//	adBuf = adc_value[R_AD_CH_BT];
//	log_printf("VBT：%d\n",adBuf);
	
//	adBuf = user_getAD(AD_CH_VBAT);
//	log_printf("user_getAD_VBAT：%d\n",adBuf);
//	temp = get_tone_status();
//	log_printf("!!!!!!!!!!!!!tone_status = %d\n",temp);
	#endif	

	#if 0
	temp = is_dac_mute(); //dac_mute(0, 1);
	log_printf("dac_mute = %d\n",temp);
	temp = is_auto_mute(); //dac_mute(0, 1);
	log_printf("auto_mute = %d\n",temp);
	
	for(adNum=0;adNum<4;adNum++)
	{
		adBuf = user_getAD(AD_CH_PC4);
		adSum += adBuf;
	}
	temp = adSum>>2;
	log_printf("LedadBuf = %d\n",temp);
	
	switch(mode)
	{
		case MODE_POWEROFF:
			log_printf("MODE_POWEROFF\n");
			break;
		case MODE_LED_W_LV1:
			log_printf("MODE_LED_W_LV1\n");
			break;
		case MODE_LED_W_LV2:
			log_printf("MODE_LED_W_LV2\n");
			break;
		case MODE_LED_W_LV3:
			log_printf("MODE_LED_W_LV3\n");
			break;
		case MODE_LED_R_LV1:
			log_printf("MODE_LED_R_LV1\n");
			break;
		case MODE_LED_R_LV2:
			log_printf("MODE_LED_R_LV2\n");
			break;
		default:
			break;
	}
	#endif
//	log_printf("pwmBoostDuty = %d\n",pwmBoostDuty);
//	log_printf("pwmLedRDuty = %d\n",pwmLedRDuty);
//	log_printf("pwmLedWDuty = %d\n",pwmLedWDuty);

	adBuf = adc_value[R_AD_CH_PC3];
	log_printf("LED电流AD值：%d\n",adBuf);
	
#if 0

	log_printf("btStata = %d\n",btStata);
	adBuf = adc_value[R_AD_CH_PB1];
	log_printf("keycode = %d\n",adBuf);
	
	
	temp = get_bt_connect_status();
	switch(temp)
	{
	case BT_STATUS_INITING:          /*正在初始化*/
		log_printf("正在初始化\n");
		break;
	case BT_STATUS_WAITINT_CONN:     /*等待连接*/
		log_printf("等待连接\n");
		break;
	case BT_STATUS_AUTO_CONNECTINT:  /*正在回连*/
		log_printf("正在回连\n");
		break;
	case BT_STATUS_TAKEING_PHONE:    /*正在电话*/
		log_printf("正在电话\n");
		break;
	case BT_STATUS_CONNECTING:       /*已连接，没有电话和音乐在活动*/
		log_printf("已连接，没有电话和音乐在活动\n");
		break;
	case BT_STATUS_PLAYING_MUSIC:    /*正在音乐*/
		log_printf("正在音乐\n");
		break;
	default:
		break;
	}
	#endif
}

void app_enter_sleep_mode_1()
{
	extern void set_sys_freq(u32 out_freq);
	#define IDLE_Hz 120000000L
	set_sys_freq(IDLE_Hz);
	enter_sys_sleep_mode();
//	enter_sys_soft_poweroff();
}

void user_voutEn()		//1s
{
	u16 temp = 0;
	static u8 cnt = 5;

	temp = get_tone_status();

	
	
	if((mode != MODE_POWEROFF)||(btStata != BT_STATA_IDEL)|| F_isVin)
	{
		cnt = 5;
	}
	else if(temp == 0)
	{
		temp = adc_value[R_AD_CH_PB1];
			
		if(temp == 0)
		{
			if(cnt)
			{
				cnt--;
			}
			else
			{
			//	log_printf("user app_enter_sleep_mode_1 IN!!!\n");
			//	app_enter_sleep_mode_1();
			//	enter_sys_soft_poweroff();
			//	log_printf("user app_enter_sleep_mode_1 OUT!!!\n");
				IO_poweronEn_clr;
			}
		}
		else
		{
			IO_poweronEn_set;
		}
	}
}

#if BT_TWS
void user_tws_scan()
{
	if(btStata == BT_STATA_IDEL)
		return;
	if((is_1t2_connection()<1)&&(is_tws_device_slave() == 0))
	{
		task_post_msg(NULL, 1, MSG_BT_SEARCH_DEVICE);
		task_post_msg(NULL, 1, MSG_BT_PAGE_SCAN);
	}
}

LOOP_DETECT_REGISTER(user_tws_scan_detect) = {
//LOOP_UI_REGISTER(user_led_scan_detect) = {
//TWS_DETECT_REGISTER(user_led_scan_detect) = {
//USLOOP_DETECT_REGISTER(user_led_scan_detec) = {
    .time = 4000,
    .fun  = user_tws_scan,
};
#endif

//*
#if 0
LOOP_DETECT_REGISTER(user_dubugTest_detect) = {
    .time = 1000,
    .fun  = user_dubugTest,
};
#endif

#if 1
LOOP_DETECT_REGISTER(user_vLedDisp_detect) = {
    .time = 1,		//2ms,如需更改需要调整函数内变量
    .fun  = user_vLedDisp,
};
	
#if 1
LOOP_DETECT_REGISTER(user_getAdLed_detect) = {
    .time = 5,		//10ms,如需更改需要调整函数内变量
    .fun  = user_getAdLed,
};
#endif

LOOP_DETECT_REGISTER(user_btStataScan_detect) = {
    .time = 25,
    .fun  = user_btStataScan,
};

LOOP_DETECT_REGISTER(user_keyScan_detect) = {
    .time = 10,
    .fun  = user_keyScan,
};

LOOP_DETECT_REGISTER(user_voutEn_detect) = {
    .time = 500,		//1s,如需更改需要调整函数内变量
    .fun  = user_voutEn,
};
#endif

#endif

// */
