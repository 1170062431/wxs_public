#include "sdk_cfg.h"
#include "led.h"
#include "timer.h"
#include "clock_api.h"
#include "common.h"
#include "board_init.h"
#include "bluetooth/bt_led.h"
#include "key.h"
#include "user_pwm.h"
#include "adc_api.h"
#include "rtc/rtc_api.h"
#include "key_drv_ad.h"
#include "power.h"

u16 pwmBoostDuty,pwmLedRDuty,pwmLedWDuty;

#if	0
void user_setPwm(u8 channel,u8 pwm_duty)
{
	switch(channel)
	{
	case PWM_CH_BOOST:
		pwmBoostDuty = pwm_duty;
		break;
	case PWM_CH_LED_R:
		pwmLedRDuty = pwm_duty;
		break;
	case PWM_CH_LED_W:
		pwmLedWDuty = pwm_duty;
		break;
	default:
		break;
	}
}

 /*
LOOP_DETECT_REGISTER(user_led_scan_detect) = {
    .time = 250,
    .fun  = user_led_scan,
};
// */

#endif


