#ifndef __UTF16TOANSI_H__
#define __UTF16TOANSI_H__

#include "typedef.h"

u16 utf16tocountryGB(u16 utf);

#endif
